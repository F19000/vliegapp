import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Vliegtuig> vliegtuigen = new ArrayList<Vliegtuig>();
        vliegtuigen.add(new Vliegtuig(1200, 2, false, false, 10, 800, false));
    }
}