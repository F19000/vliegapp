package tests;

import org.junit.Test;

import static java.awt.AWTEventMulticaster.add;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class VliegtuigTest {

    @Test
    public void testVliegtuig() {
        // Arrange
        ArrayList<Vliegtuig> vliegtuigen = new ArrayList<Vliegtuig>() {{
            add(new Vliegtuig(1200, 2, true, false, 10, 800, false)); // Bagage = true, Lading = 800, Gewicht = 1200
            add(new Vliegtuig(1200, 2, false, false, 10, 8000, false)); // Bagage = false, Lading = 8000, Gewicht = 1200
            add(new Vliegtuig(1000, 2, false, false, 10, 800, false)); // Bagage = false, Lading = 800, Gewicht = 1000
        }};

        // Act and Assert
        for (Vliegtuig v : vliegtuigen) {
            boolean hasBagage = v.getBaggage();
            int lading = v.getLading();
            int gewicht = v.getGewicht();

            if (hasBagage && (lading >= 8000 || gewicht >= 1200)) {
                fail("ongeldig");            }

            if (!hasBagage && (lading >= 8000 && gewicht >= 1000)) {
                fail("ongeldig");            }

            if (gewicht >= 1200 && (hasBagage || lading >= 8000)) {
                fail("ongeldig");            }

            if (gewicht >= 1000 && !hasBagage && lading < 8000) {
                fail("ongeldig");
            }

            assertTrue(true);
        }
    }
}
