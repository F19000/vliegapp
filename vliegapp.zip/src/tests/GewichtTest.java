package tests;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;

public class GewichtTest {
    @Test
            public void GewichtTest(){
    //Arrange
    int gewicht = 0;
    int expectedOutcome = 1000;
        ArrayList<Vliegtuig> vliegtuigen = new ArrayList<Vliegtuig>() {{
            add(new Vliegtuig1(1000, 2, false, false, 10, 800, false));
        }};
        //act
        for(Vliegtuig i : vliegtuigen) {
            gewicht += i.getGewicht;

        }
        assertTrue(gewicht < 1000);
    }}