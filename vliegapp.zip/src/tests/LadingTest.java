package tests;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LadingTest {
    @Test
    public void testLading() {
        // Arrange
        Vliegtuig vliegtuig = new Vliegtuig(1200, 2, false, false, 10, 8000, false);
        int expectedLading = 8000;

        // Act
        int actualLading = vliegtuig.getLading();

        // Assert
        assertEquals(expectedLading, actualLading);
    }
}

