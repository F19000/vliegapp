package tests;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertTrue;

public class BagageTest {
    @Test
    public void testBagage() {
        // Arrange
        ArrayList<Vliegtuig> vliegtuigen = new ArrayList<Vliegtuig>() {{
            add(new Vliegtuig(1200, 2, true, false, 10, 800, false));
        }};

        // Act and assert
        for(Vliegtuig v : vliegtuigen) {
            assertTrue(v.getBaggage());
        }
    }
}